package com.rmf.kuhcjr;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.rmf.kuhcjr.Fragments.BerandaFragment;
import com.rmf.kuhcjr.Fragments.Kegiatan;
import com.rmf.kuhcjr.Fragments.Laporan;
import com.rmf.kuhcjr.Fragments.ProfileFragment;
import com.rmf.kuhcjr.Pengajuan.PengajuanCuti;
import com.rmf.kuhcjr.Pengajuan.PengajuanDinas;
import com.rmf.kuhcjr.Pengajuan.PengajuanLembur;

public class MenuUtama extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private MenuItem itemBeranda,itemProfil;
    private Fragment fragmentBeranda,fragmentProfil;
    private String tag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama);
        //        Sistem
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        //make fully Android Transparent Status bar
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
            getWindow().setStatusBarColor(Color.TRANSPARENT);

        }

        fragmentBeranda = new BerandaFragment();
        fragmentProfil = new ProfileFragment();

        initialUI();
        actionUI();


        tag ="beranda";

        getSupportFragmentManager().beginTransaction().replace(R.id.frame_container,
                fragmentBeranda,tag).commit();


    }

    private void initialUI(){
        bottomNav = (BottomNavigationView) findViewById(R.id.navigation);
    }
    private void actionUI(){
        bottomNav.setOnNavigationItemSelectedListener(navListener);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                    FragmentManager fm = getSupportFragmentManager();

                    switch (item.getItemId()) {
                        case R.id.navigation_home:

                            if(fm.findFragmentByTag("beranda")!=null){
                                fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,
                                        android.R.anim.fade_out).show(fm.findFragmentByTag("beranda")).commit();
                            }
                            else{
                                fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,
                                        android.R.anim.fade_out).add(R.id.frame_container,fragmentBeranda,"beranda").commit();
                            }
                            if(fm.findFragmentByTag("profil")!=null){
                                fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,
                                        android.R.anim.fade_out).hide(fm.findFragmentByTag("profil")).commit();


                            }

                            break;
                        case R.id.navigation_profile:

                            if(fm.findFragmentByTag("profil")!=null){
                                fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,
                                        android.R.anim.fade_out).show(fm.findFragmentByTag("profil")).commit();
                            }
                            else{
                                fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,
                                        android.R.anim.fade_out).add(R.id.frame_container,fragmentProfil,"profil").commit();
                            }
                            if(fm.findFragmentByTag("beranda")!=null){
                                fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,
                                        android.R.anim.fade_out).hide(fm.findFragmentByTag("beranda")).commit();


                            }

                            break;


                    }
                    return true;
                }
            };




    public static void setWindowFlag(Activity activity, final int bits, boolean on) {
        Window win = activity.getWindow();
        WindowManager.LayoutParams winParams = win.getAttributes();
        if (on) {
            winParams.flags |= bits;
        } else {
            winParams.flags &= ~bits;
        }
        win.setAttributes(winParams);
    }
}
